#!/usr/bin/env python3
"""Restricted SSH forced command for reviewed VPS release operations."""

import os
import hashlib
import json
import re
import stat
import subprocess
import sys
from pathlib import Path


EVIDENCE = Path("/srv/rsl-siege/evidence")
PROJECT = Path("/srv/rsl-siege")
REVIEWED_SOURCE = Path("/opt/rsl-siege-manager")
PREFLIGHT_SCRIPT = REVIEWED_SOURCE / "scripts/portable-vps-release-preflight.py"
PLAN_SCRIPT = REVIEWED_SOURCE / "scripts/portable-vps-release-pause-backup.py"
RECOVERY_PROOF_SCRIPT = REVIEWED_SOURCE / "scripts/portable-vps-release-recovery-proof.py"
MIGRATION_READY_SCRIPT = REVIEWED_SOURCE / "scripts/portable-vps-release-migration-ready.py"
MIGRATE_SCRIPT = REVIEWED_SOURCE / "scripts/portable-vps-release-migrate.py"
PROMOTION_READY_SCRIPT = REVIEWED_SOURCE / "scripts/portable-vps-release-promotion-ready.py"
PROMOTE_SCRIPT = REVIEWED_SOURCE / "scripts/portable-vps-release-promote.py"
ACCEPT_SCRIPT = REVIEWED_SOURCE / "scripts/portable-vps-release-accept.py"
RECOVER_SCRIPT = REVIEWED_SOURCE / "scripts/portable-vps-release-recover.py"
BACKUP_PROFILE = PROJECT / "runtime/release-backup-profile.json"
ACCEPT_INPUTS = Path("/root/vps-release-acceptance")
PILOT_CONFIG = ACCEPT_INPUTS / "pilot.json"
SESSION_COOKIE = ACCEPT_INPUTS / "session-cookie"
EXTERNAL_REPORTS = Path("/root/vps-release-reports")
STAGE_SCRIPT_BACKUP = REVIEWED_SOURCE / "scripts/portable-vps-remote.py.before-release-stage"
INITIAL_REMOTE_SHA256 = "f965a4edc244c7ece696bbeb30b650f67c3c21e82584c44185ca57a94db31da7"
MAX_MANIFEST = 16 * 1024
SHA256 = re.compile(r"[0-9a-f]{64}\Z")
RUN = re.compile(r"[1-9][0-9]{0,19}-[1-9][0-9]{0,2}\Z")
SOURCE_SHA = re.compile(r"[0-9a-f]{40}\Z")
RELEASE_ID = re.compile(r"[a-z0-9][a-z0-9._-]{2,63}\Z")
REVISION = re.compile(r"[a-zA-Z0-9_]{1,64}\Z")
PROOF_PATH = re.compile(r"/[a-zA-Z0-9._/-]{1,254}\Z")


def private_directory(path):
    try:
        metadata = Path(path).lstat()
    except OSError:
        return False
    return (
        stat.S_ISDIR(metadata.st_mode)
        and metadata.st_uid == 0
        and metadata.st_mode & 0o077 == 0
    )


def reviewed_script(path):
    try:
        info = path.lstat()
    except OSError:
        return False
    return stat.S_ISREG(info.st_mode) and info.st_uid == 0 and not info.st_mode & 0o022


def private_file(path):
    try:
        info = path.lstat()
    except OSError:
        return False
    return stat.S_ISREG(info.st_mode) and info.st_uid == 0 and not info.st_mode & 0o077


def profile_bound():
    """Keep every profile-driven operation inside the staged project."""
    try:
        if not private_file(BACKUP_PROFILE) or not 0 < BACKUP_PROFILE.stat().st_size <= 4096:
            return False
        value = json.loads(BACKUP_PROFILE.read_bytes(), object_pairs_hook=no_duplicate_keys)
        return isinstance(value, dict) and value.get("project_directory") == str(PROJECT)
    except (OSError, ValueError, TypeError, UnicodeError):
        return False


def reviewed_checkout(source_sha):
    head = subprocess.run(
        ["git", "-C", str(REVIEWED_SOURCE), "rev-parse", "HEAD"],
        capture_output=True, timeout=10, check=False,
    )
    changed = subprocess.run(
        ["git", "-C", str(REVIEWED_SOURCE), "status", "--porcelain", "--untracked-files=all"],
        capture_output=True, timeout=10, check=False,
    )
    if head.returncode != 0 or head.stdout.strip() != source_sha.encode() or changed.returncode != 0:
        return False
    entries = changed.stdout.splitlines()
    if not entries:
        return True
    return (entries == [b"?? scripts/portable-vps-remote.py.before-release-stage"]
            and private_file(STAGE_SCRIPT_BACKUP)
            and hashlib.sha256(STAGE_SCRIPT_BACKUP.read_bytes()).hexdigest() == INITIAL_REMOTE_SHA256)


def succeeds(arguments):
    try:
        result = subprocess.run(arguments, capture_output=True, timeout=10, check=False)
        return result.returncode == 0
    except (OSError, subprocess.TimeoutExpired):
        return False


def access_check():
    return all(
        private_directory(path)
        for path in ("/srv/rsl-siege", "/srv/rsl-siege/runtime", "/srv/rsl-siege/evidence")
    ) and all(
        succeeds(command)
        for command in (
            ["docker", "compose", "version"],
            ["docker", "info"],
            ["systemctl", "is-active", "--quiet", "rsl-production-backup.timer"],
        )
    )


def no_duplicate_keys(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate JSON key")
        result[key] = value
    return result


def exact_keys(value, required, optional=()):
    return isinstance(value, dict) and set(required) <= set(value) <= set(required) | set(optional)


def image(value, name):
    prefix = f"ghcr.io/glitchwerks/{name}@sha256:"
    return isinstance(value, str) and value.startswith(prefix) and bool(
        SHA256.fullmatch(value[len(prefix):])
    )


def valid_migrations(value):
    if not exact_keys(value, ("siege", "mom", "order")):
        return False
    changed = []
    for name in ("siege", "mom"):
        item = value[name]
        if not exact_keys(item, ("mode", "from_revision", "to_revision")):
            return False
        before, after = item["from_revision"], item["to_revision"]
        if not all(isinstance(revision, str) and REVISION.fullmatch(revision)
                   and revision.lower() not in {"head", "heads", "base", "current"}
                   for revision in (before, after)):
            return False
        if item["mode"] == "none" and before == after:
            continue
        if item["mode"] == "upgrade" and before != after:
            changed.append(name)
            continue
        return False
    order = value["order"]
    return (isinstance(order, list)
            and all(type(name) is str and name in ("siege", "mom") for name in order)
            and len(order) == len(set(order)) and set(order) == set(changed))


def valid_manifest(raw):
    try:
        data = json.loads(raw.decode("utf-8"), object_pairs_hook=no_duplicate_keys)
    except (UnicodeError, ValueError, TypeError, RecursionError):
        return False
    if not exact_keys(data, ("schema_version", "release_id", "siege", "mom", "configuration", "migrations")):
        return False
    if type(data["schema_version"]) is not int or data["schema_version"] != 2:
        return False
    if not isinstance(data["release_id"], str) or not RELEASE_ID.fullmatch(data["release_id"]):
        return False
    siege, mom, config = data["siege"], data["mom"], data["configuration"]
    if not exact_keys(siege, ("source_sha", "ci_run_id", "api_image", "frontend_image"),
                      ("reference_bot_image",)):
        return False
    if not exact_keys(mom, ("source_sha", "ci_run_id", "image", "portable_auth", "scheduler_progress")):
        return False
    if not exact_keys(config, ("source_sha", "topology")):
        return False
    if not all(isinstance(item["source_sha"], str) and SOURCE_SHA.fullmatch(item["source_sha"])
               for item in (siege, mom, config)):
        return False
    if config["source_sha"] != siege["source_sha"] or config["topology"] != "mom":
        return False
    if any(type(item["ci_run_id"]) is not int or item["ci_run_id"] <= 0
           for item in (siege, mom)):
        return False
    if mom["portable_auth"] is not True or mom["scheduler_progress"] is not True:
        return False
    if not valid_migrations(data["migrations"]):
        return False
    return (image(siege["api_image"], "siege-api")
            and image(siege["frontend_image"], "siege-frontend")
            and image(mom["image"], "mom-bot")
            and ("reference_bot_image" not in siege
                 or image(siege["reference_bot_image"], "siege-bot")))


def write_private(path, data):
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW
    descriptor = os.open(path, flags, 0o600)
    with os.fdopen(descriptor, "wb") as output:
        output.write(data)
        output.flush()
        os.fsync(output.fileno())


def stage_release(expected, run_id, stream):
    checks = {
        "root_execution": os.geteuid() == 0,
        "request_shape": bool(SHA256.fullmatch(expected)) and bool(RUN.fullmatch(run_id)),
        "read_only_baseline": access_check(),
    }
    report_dir = None
    if all(checks.values()):
        try:
            base = EVIDENCE / "release-stages"
            try:
                base.mkdir(mode=0o700)
            except FileExistsError:
                pass
            checks["stage_parent_private"] = private_directory(base)
            if checks["stage_parent_private"]:
                report_dir = base / run_id
                report_dir.mkdir(mode=0o700)
                checks["stage_report_private"] = private_directory(report_dir)
            if all(checks.values()):
                raw = stream.read(MAX_MANIFEST + 1)
                checks["input_bounded"] = 0 < len(raw) <= MAX_MANIFEST
                checks["manifest_digest"] = checks["input_bounded"] and (
                    hashlib.sha256(raw).hexdigest() == expected
                )
                checks["manifest_shape"] = checks["manifest_digest"] and valid_manifest(raw)
                if checks["manifest_shape"]:
                    write_private(report_dir / "candidate.json", raw)
                    checks["manifest_stored"] = True
        except (OSError, ValueError, TypeError):
            checks["stage_io"] = False
    status = "PASS" if all(checks.values()) else "STOP"
    report = {"phase": "stage-release", "status": status, "checks": checks}
    if report_dir is not None and checks.get("stage_report_private"):
        try:
            write_private(report_dir / "report.json", (json.dumps(report, sort_keys=True) + "\n").encode())
        except OSError:
            report = {"phase": "stage-release", "status": "STOP", "checks": {"report_write": False}}
    print(json.dumps(report, sort_keys=True))
    return 0 if report["status"] == "PASS" else 1


def preflight_release(expected, run_id):
    """Invoke only the reviewed, staged candidate's read-only preflight."""
    stage = EVIDENCE / "release-stages" / run_id
    checks = {
        "root_execution": os.geteuid() == 0,
        "request_shape": bool(SHA256.fullmatch(expected)) and bool(RUN.fullmatch(run_id)),
        "read_only_baseline": access_check(),
    }
    if all(checks.values()):
        try:
            checks["stage_private"] = private_directory(stage)
            candidate = stage / "candidate.json"
            staged_report = stage / "report.json"
            checks["stage_files_private"] = all(
                private_file(path) for path in (candidate, staged_report)
            ) if checks["stage_private"] else False
            checks["stage_files_bounded"] = (
                0 < candidate.stat().st_size <= MAX_MANIFEST
                and 0 < staged_report.stat().st_size <= 4096
            ) if checks["stage_files_private"] else False
            if checks["stage_files_bounded"]:
                raw = candidate.read_bytes()
                staged = json.loads(staged_report.read_bytes(), object_pairs_hook=no_duplicate_keys)
                checks["staged_candidate_bound"] = (
                    0 < len(raw) <= MAX_MANIFEST and hashlib.sha256(raw).hexdigest() == expected
                    and valid_manifest(raw) and isinstance(staged, dict)
                    and staged.get("phase") == "stage-release" and staged.get("status") == "PASS"
                    and isinstance(staged.get("checks"), dict) and bool(staged["checks"])
                    and all(value is True for value in staged["checks"].values())
                )
            if checks.get("staged_candidate_bound"):
                source_sha = json.loads(raw, object_pairs_hook=no_duplicate_keys)["configuration"]["source_sha"]
                checks["reviewed_checkout"] = reviewed_checkout(source_sha)
                checks["reviewed_script"] = reviewed_script(PREFLIGHT_SCRIPT)
            if checks.get("reviewed_checkout") and checks.get("reviewed_script"):
                EXTERNAL_REPORTS.mkdir(mode=0o700, exist_ok=True)
                checks["external_report_directory_private"] = private_directory(EXTERNAL_REPORTS)
            if checks.get("external_report_directory_private"):
                private_report = EXTERNAL_REPORTS / f"{run_id}-preflight.json"
                result = subprocess.run(
                    ["/usr/bin/python3", "-I", "-B", str(PREFLIGHT_SCRIPT),
                     "--project-directory", str(PROJECT), "--stage-run-id", run_id,
                     "--manifest-sha256", expected,
                     "--report", str(private_report)],
                    env={"PATH": "/usr/bin:/bin", "PYTHONNOUSERSITE": "1",
                         "PYTHONDONTWRITEBYTECODE": "1", "PYTHONSAFEPATH": "1"},
                    capture_output=True, timeout=300, check=False,
                )
                evidence = json.loads(private_report.read_bytes(), object_pairs_hook=no_duplicate_keys)
                checks["preflight_passed"] = (
                    result.returncode == 0 and result.stdout.strip() == b"PASS"
                    and isinstance(evidence, dict) and evidence.get("phase") == "release-preflight"
                    and evidence.get("status") == "PASS" and isinstance(evidence.get("checks"), dict)
                    and bool(evidence["checks"]) and all(value is True for value in evidence["checks"].values())
                )
        except (OSError, ValueError, TypeError, KeyError, subprocess.TimeoutExpired):
            checks["preflight_execution"] = False
    status = "PASS" if all(checks.values()) else "STOP"
    report = {"phase": "release-preflight-dispatch", "status": status, "checks": checks}
    if checks.get("stage_private"):
        try:
            write_private(stage / "preflight-dispatch-report.json", (json.dumps(report, sort_keys=True) + "\n").encode())
        except OSError:
            report = {"phase": "release-preflight-dispatch", "status": "STOP", "checks": {"report_write": False}}
    print(json.dumps(report, sort_keys=True))
    return 0 if report["status"] == "PASS" else 1


def plan_release(expected, run_id):
    """Record a candidate-bound pause plan without stopping a writer."""
    stage = EVIDENCE / "release-stages" / run_id
    checks = {
        "root_execution": os.geteuid() == 0,
        "request_shape": bool(SHA256.fullmatch(expected)) and bool(RUN.fullmatch(run_id)),
        "read_only_baseline": access_check(),
    }
    plan_sha256 = None
    if all(checks.values()):
        try:
            candidate = stage / "candidate.json"
            checks["stage_private"] = private_directory(stage)
            checks["candidate_private_bounded"] = (
                private_file(candidate) and 0 < candidate.stat().st_size <= MAX_MANIFEST
            ) if checks["stage_private"] else False
            if checks["candidate_private_bounded"]:
                raw = candidate.read_bytes()
                checks["candidate_digest"] = (
                    hashlib.sha256(raw).hexdigest() == expected and valid_manifest(raw)
                )
            if checks.get("candidate_digest"):
                source_sha = json.loads(raw, object_pairs_hook=no_duplicate_keys)["configuration"]["source_sha"]
                checks["reviewed_checkout"] = reviewed_checkout(source_sha)
                checks["reviewed_script"] = reviewed_script(PLAN_SCRIPT)
                checks["profile_bound"] = profile_bound()
            if (checks.get("reviewed_checkout") and checks.get("reviewed_script")
                    and checks.get("profile_bound")):
                EXTERNAL_REPORTS.mkdir(mode=0o700, exist_ok=True)
                checks["external_report_directory_private"] = private_directory(EXTERNAL_REPORTS)
            if checks.get("external_report_directory_private"):
                external = EXTERNAL_REPORTS / f"{run_id}-plan.json"
                result = subprocess.run(
                    ["/usr/bin/python3", "-I", "-B", str(PLAN_SCRIPT), "plan",
                     "--profile", str(BACKUP_PROFILE), "--stage-run-id", run_id,
                     "--manifest-sha256", expected, "--report", str(external)],
                    env={"PATH": "/usr/bin:/bin", "PYTHONNOUSERSITE": "1",
                         "PYTHONDONTWRITEBYTECODE": "1", "PYTHONSAFEPATH": "1"},
                    capture_output=True, timeout=300, check=False,
                )
                evidence = json.loads(external.read_bytes(), object_pairs_hook=no_duplicate_keys)
                checks["plan_passed"] = (
                    result.returncode == 0 and result.stdout.strip() == b"PASS"
                    and isinstance(evidence, dict) and evidence.get("phase") == "plan"
                    and evidence.get("status") == "PASS" and isinstance(evidence.get("checks"), dict)
                    and bool(evidence["checks"]) and all(value is True for value in evidence["checks"].values())
                )
            if checks.get("plan_passed"):
                plan_file = stage / "pause-plan.json"
                checks["plan_private_bounded"] = (
                    private_file(plan_file) and 0 < plan_file.stat().st_size <= 4096
                )
                if checks["plan_private_bounded"]:
                    plan_sha256 = hashlib.sha256(plan_file.read_bytes()).hexdigest()
        except (OSError, ValueError, TypeError, KeyError, subprocess.TimeoutExpired):
            checks["plan_execution"] = False
    status = "PASS" if all(checks.values()) and plan_sha256 is not None else "STOP"
    report = {"phase": "release-pause-plan-dispatch", "status": status, "checks": checks}
    if status == "PASS":
        report["plan_sha256"] = plan_sha256
    if checks.get("stage_private"):
        try:
            write_private(stage / "plan-dispatch-report.json", (json.dumps(report, sort_keys=True) + "\n").encode())
        except OSError:
            report = {"phase": "release-pause-plan-dispatch", "status": "STOP", "checks": {"report_write": False}}
    print(json.dumps(report, sort_keys=True))
    return 0 if report["status"] == "PASS" else 1


def pause_release(expected, run_id, plan_sha256):
    """Stop only the reviewed writers after binding the accepted plan."""
    stage = EVIDENCE / "release-stages" / run_id
    checks = {
        "root_execution": os.geteuid() == 0,
        "request_shape": all((SHA256.fullmatch(expected), RUN.fullmatch(run_id),
                              SHA256.fullmatch(plan_sha256))),
        "read_only_baseline": access_check(),
    }
    if all(checks.values()):
        try:
            checks["stage_private"] = private_directory(stage)
            checks["dispatch_report_available"] = (
                not (stage / "pause-dispatch-report.json").exists()
                and not (stage / "pause-dispatch-report.json").is_symlink()
            ) if checks["stage_private"] else False
            candidate = stage / "candidate.json"
            plan_file = stage / "pause-plan.json"
            plan_report = stage / "plan-report.json"
            checks["bound_files_private"] = checks["stage_private"] and all(
                private_file(path) and 0 < path.stat().st_size <= limit
                for path, limit in ((candidate, MAX_MANIFEST), (plan_file, 4096),
                                    (plan_report, 4096))
            )
            if checks["bound_files_private"]:
                raw = candidate.read_bytes()
                plan_evidence = json.loads(plan_report.read_bytes(), object_pairs_hook=no_duplicate_keys)
                checks["candidate_bound"] = (hashlib.sha256(raw).hexdigest() == expected
                                             and valid_manifest(raw))
                checks["accepted_plan_bound"] = (
                    hashlib.sha256(plan_file.read_bytes()).hexdigest() == plan_sha256
                    and isinstance(plan_evidence, dict)
                    and plan_evidence.get("phase") == "plan"
                    and plan_evidence.get("status") == "PASS"
                    and isinstance(plan_evidence.get("checks"), dict)
                    and bool(plan_evidence["checks"])
                    and all(value is True for value in plan_evidence["checks"].values())
                )
            if checks.get("candidate_bound") and checks.get("accepted_plan_bound"):
                source_sha = json.loads(raw, object_pairs_hook=no_duplicate_keys)["configuration"]["source_sha"]
                checks["reviewed_checkout"] = reviewed_checkout(source_sha)
                checks["reviewed_script"] = reviewed_script(PLAN_SCRIPT)
                checks["profile_bound"] = profile_bound()
            if (checks.get("reviewed_checkout") and checks.get("reviewed_script")
                    and checks.get("profile_bound")):
                EXTERNAL_REPORTS.mkdir(mode=0o700, exist_ok=True)
                checks["external_report_directory_private"] = private_directory(EXTERNAL_REPORTS)
            if (checks.get("external_report_directory_private")
                    and checks.get("dispatch_report_available")):
                write_private(stage / "pause-dispatch-start.json", b'{"phase":"pause-dispatch","status":"INCOMPLETE"}\n')
                checks["dispatch_reserved"] = True
                external = EXTERNAL_REPORTS / f"{run_id}-pause.json"
                result = subprocess.run(
                    ["/usr/bin/python3", "-I", "-B", str(PLAN_SCRIPT), "pause",
                     "--profile", str(BACKUP_PROFILE), "--stage-run-id", run_id,
                     "--manifest-sha256", expected, "--plan-sha256", plan_sha256,
                     "--confirm-pause", "--report", str(external)],
                    env={"PATH": "/usr/bin:/bin", "PYTHONNOUSERSITE": "1",
                         "PYTHONDONTWRITEBYTECODE": "1", "PYTHONSAFEPATH": "1"},
                    capture_output=True, timeout=180, check=False,
                )
                evidence = json.loads(external.read_bytes(), object_pairs_hook=no_duplicate_keys)
                checks["pause_passed"] = (
                    result.returncode == 0 and result.stdout.strip() == b"PASS"
                    and isinstance(evidence, dict) and evidence.get("phase") == "pause"
                    and evidence.get("status") == "PASS"
                    and isinstance(evidence.get("checks"), dict) and bool(evidence["checks"])
                    and all(value is True for value in evidence["checks"].values())
                )
        except (OSError, ValueError, TypeError, KeyError, subprocess.TimeoutExpired):
            checks["pause_execution"] = False
    status = "PASS" if all(checks.values()) else "STOP"
    report = {"phase": "release-writer-pause-dispatch", "status": status, "checks": checks}
    if checks.get("dispatch_reserved"):
        try:
            write_private(stage / "pause-dispatch-report.json", (json.dumps(report, sort_keys=True) + "\n").encode())
        except OSError:
            report = {"phase": "release-writer-pause-dispatch", "status": "STOP", "checks": {"report_write": False}}
    print(json.dumps(report, sort_keys=True))
    return 0 if report["status"] == "PASS" else 1


def backup_release(expected, run_id, plan_sha256):
    """Start only the reviewed managed backup after an accepted writer pause."""
    stage = EVIDENCE / "release-stages" / run_id
    checks = {
        "root_execution": os.geteuid() == 0,
        "request_shape": all((SHA256.fullmatch(expected), RUN.fullmatch(run_id),
                              SHA256.fullmatch(plan_sha256))),
        "read_only_baseline": access_check(),
    }
    if all(checks.values()):
        try:
            checks["stage_private"] = private_directory(stage)
            checks["dispatch_report_available"] = (
                not (stage / "backup-dispatch-report.json").exists()
                and not (stage / "backup-dispatch-report.json").is_symlink()
            ) if checks["stage_private"] else False
            candidate = stage / "candidate.json"
            plan_file = stage / "pause-plan.json"
            plan_report = stage / "plan-report.json"
            pause_report = stage / "pause-report.json"
            checks["bound_files_private"] = checks["stage_private"] and all(
                private_file(path) and 0 < path.stat().st_size <= limit
                for path, limit in ((candidate, MAX_MANIFEST), (plan_file, 4096),
                                    (plan_report, 4096), (pause_report, 4096))
            )
            if checks["bound_files_private"]:
                raw = candidate.read_bytes()
                plan_evidence = json.loads(plan_report.read_bytes(), object_pairs_hook=no_duplicate_keys)
                pause_evidence = json.loads(pause_report.read_bytes(), object_pairs_hook=no_duplicate_keys)
                checks["candidate_bound"] = (hashlib.sha256(raw).hexdigest() == expected
                                             and valid_manifest(raw))
                checks["accepted_plan_bound"] = (
                    hashlib.sha256(plan_file.read_bytes()).hexdigest() == plan_sha256
                    and isinstance(plan_evidence, dict)
                    and plan_evidence.get("phase") == "plan"
                    and plan_evidence.get("status") == "PASS"
                    and isinstance(plan_evidence.get("checks"), dict)
                    and bool(plan_evidence["checks"])
                    and all(value is True for value in plan_evidence["checks"].values())
                )
                checks["accepted_pause"] = (
                    isinstance(pause_evidence, dict) and pause_evidence.get("phase") == "pause"
                    and pause_evidence.get("status") == "PASS"
                    and isinstance(pause_evidence.get("checks"), dict)
                    and bool(pause_evidence["checks"])
                    and all(value is True for value in pause_evidence["checks"].values())
                )
            if (checks.get("candidate_bound") and checks.get("accepted_plan_bound")
                    and checks.get("accepted_pause")):
                source_sha = json.loads(raw, object_pairs_hook=no_duplicate_keys)["configuration"]["source_sha"]
                checks["reviewed_checkout"] = reviewed_checkout(source_sha)
                checks["reviewed_script"] = reviewed_script(PLAN_SCRIPT)
                checks["profile_bound"] = profile_bound()
            if (checks.get("reviewed_checkout") and checks.get("reviewed_script")
                    and checks.get("profile_bound")):
                EXTERNAL_REPORTS.mkdir(mode=0o700, exist_ok=True)
                checks["external_report_directory_private"] = private_directory(EXTERNAL_REPORTS)
            if (checks.get("external_report_directory_private")
                    and checks.get("dispatch_report_available")):
                write_private(stage / "backup-dispatch-start.json", b'{"phase":"backup-dispatch","status":"INCOMPLETE"}\n')
                checks["dispatch_reserved"] = True
                external = EXTERNAL_REPORTS / f"{run_id}-backup.json"
                result = subprocess.run(
                    ["/usr/bin/python3", "-I", "-B", str(PLAN_SCRIPT), "backup",
                     "--profile", str(BACKUP_PROFILE), "--stage-run-id", run_id,
                     "--manifest-sha256", expected, "--plan-sha256", plan_sha256,
                     "--confirm-backup", "--report", str(external)],
                    env={"PATH": "/usr/bin:/bin", "PYTHONNOUSERSITE": "1",
                         "PYTHONDONTWRITEBYTECODE": "1", "PYTHONSAFEPATH": "1"},
                    capture_output=True, timeout=2400, check=False,
                )
                evidence = json.loads(external.read_bytes(), object_pairs_hook=no_duplicate_keys)
                checks["backup_passed"] = (
                    result.returncode == 0 and result.stdout.strip() == b"PASS"
                    and isinstance(evidence, dict) and evidence.get("phase") == "backup"
                    and evidence.get("status") == "PASS"
                    and isinstance(evidence.get("checks"), dict) and bool(evidence["checks"])
                    and all(value is True for value in evidence["checks"].values())
                )
        except (OSError, ValueError, TypeError, KeyError, subprocess.TimeoutExpired):
            checks["backup_execution"] = False
    status = "PASS" if all(checks.values()) else "STOP"
    report = {"phase": "release-managed-backup-dispatch", "status": status, "checks": checks}
    if checks.get("dispatch_reserved"):
        try:
            write_private(stage / "backup-dispatch-report.json", (json.dumps(report, sort_keys=True) + "\n").encode())
        except OSError:
            report = {"phase": "release-managed-backup-dispatch", "status": "STOP", "checks": {"report_write": False}}
    print(json.dumps(report, sort_keys=True))
    return 0 if report["status"] == "PASS" else 1


def proof_release(expected, run_id, plan_sha256, recover_report, restore_report):
    """Bind the selected backup to independent read-only recovery evidence."""
    stage = EVIDENCE / "release-stages" / run_id
    paths = (Path(recover_report), Path(restore_report))
    checks = {
        "root_execution": os.geteuid() == 0,
        "request_shape": bool(SHA256.fullmatch(expected)) and bool(RUN.fullmatch(run_id))
            and bool(SHA256.fullmatch(plan_sha256))
            and all(PROOF_PATH.fullmatch(path) and ".." not in item.parts
                    for path, item in zip((recover_report, restore_report), paths))
            and paths[0] != paths[1],
        "read_only_baseline": access_check(),
    }
    if all(checks.values()):
        try:
            checks["stage_private"] = private_directory(stage)
            checks["dispatch_report_available"] = (
                not (stage / "proof-dispatch-report.json").exists()
                and not (stage / "proof-dispatch-report.json").is_symlink()
            ) if checks["stage_private"] else False
            candidate = stage / "candidate.json"
            plan_file = stage / "pause-plan.json"
            reports = (stage / "plan-report.json", stage / "pause-report.json",
                       stage / "backup-report.json")
            checks["bound_files_private"] = checks["stage_private"] and all(
                private_file(path) and 0 < path.stat().st_size <= limit
                for path, limit in ((candidate, MAX_MANIFEST), (plan_file, 4096),
                                    *((item, 4096) for item in reports))
            )
            if checks["bound_files_private"]:
                raw = candidate.read_bytes()
                checks["candidate_bound"] = hashlib.sha256(raw).hexdigest() == expected and valid_manifest(raw)
                checks["plan_bound"] = hashlib.sha256(plan_file.read_bytes()).hexdigest() == plan_sha256
                for phase, path in zip(("plan", "pause", "backup"), reports):
                    value = json.loads(path.read_bytes(), object_pairs_hook=no_duplicate_keys)
                    checks[f"{phase}_accepted"] = (
                        isinstance(value, dict) and value.get("phase") == phase
                        and value.get("status") == "PASS"
                        and isinstance(value.get("checks"), dict) and bool(value["checks"])
                        and all(item is True for item in value["checks"].values())
                    )
            if all(checks.values()):
                source_sha = json.loads(raw, object_pairs_hook=no_duplicate_keys)["configuration"]["source_sha"]
                checks["reviewed_checkout"] = reviewed_checkout(source_sha)
                checks["reviewed_script"] = reviewed_script(RECOVERY_PROOF_SCRIPT)
                checks["profile_bound"] = profile_bound()
            if (checks.get("reviewed_checkout") and checks.get("reviewed_script")
                    and checks.get("profile_bound")):
                EXTERNAL_REPORTS.mkdir(mode=0o700, exist_ok=True)
                checks["external_report_directory_private"] = private_directory(EXTERNAL_REPORTS)
            if (checks.get("external_report_directory_private")
                    and checks.get("dispatch_report_available")):
                write_private(stage / "proof-dispatch-start.json", b'{"phase":"proof-dispatch","status":"INCOMPLETE"}\n')
                checks["dispatch_reserved"] = True
                external = EXTERNAL_REPORTS / f"{run_id}-recovery-proof.json"
                result = subprocess.run(
                    ["/usr/bin/python3", "-I", "-B", str(RECOVERY_PROOF_SCRIPT),
                     "--profile", str(BACKUP_PROFILE), "--stage-run-id", run_id,
                     "--manifest-sha256", expected, "--plan-sha256", plan_sha256,
                     "--recover-report", recover_report, "--restore-report", restore_report,
                     "--report", str(external)],
                    env={"PATH": "/usr/bin:/bin", "PYTHONNOUSERSITE": "1",
                         "PYTHONDONTWRITEBYTECODE": "1", "PYTHONSAFEPATH": "1"},
                    capture_output=True, timeout=300, check=False,
                )
                evidence = json.loads(external.read_bytes(), object_pairs_hook=no_duplicate_keys)
                checks["proof_passed"] = (
                    result.returncode == 0 and result.stdout.strip() == b"PASS"
                    and isinstance(evidence, dict) and evidence.get("phase") == "release-recovery-proof"
                    and evidence.get("status") == "PASS"
                    and isinstance(evidence.get("checks"), dict) and bool(evidence["checks"])
                    and all(value is True for value in evidence["checks"].values())
                )
        except (OSError, ValueError, TypeError, KeyError, subprocess.TimeoutExpired):
            checks["proof_execution"] = False
    status = "PASS" if all(checks.values()) else "STOP"
    report = {"phase": "release-recovery-proof-dispatch", "status": status, "checks": checks}
    if checks.get("dispatch_reserved"):
        try:
            write_private(stage / "proof-dispatch-report.json", (json.dumps(report, sort_keys=True) + "\n").encode())
        except OSError:
            report = {"phase": "release-recovery-proof-dispatch", "status": "STOP", "checks": {"report_write": False}}
    print(json.dumps(report, sort_keys=True))
    return 0 if report["status"] == "PASS" else 1


def ready_release(expected, run_id, plan_sha256):
    """Record the exact pre-migration revisions after accepted restore proof."""
    stage = EVIDENCE / "release-stages" / run_id
    checks = {
        "root_execution": os.geteuid() == 0,
        "request_shape": bool(SHA256.fullmatch(expected)) and bool(RUN.fullmatch(run_id))
            and bool(SHA256.fullmatch(plan_sha256)),
        "read_only_baseline": access_check(),
    }
    readiness_sha256 = None
    if all(checks.values()):
        try:
            checks["stage_private"] = private_directory(stage)
            checks["dispatch_report_available"] = (
                not (stage / "ready-dispatch-report.json").exists()
                and not (stage / "ready-dispatch-report.json").is_symlink()
            ) if checks["stage_private"] else False
            candidate = stage / "candidate.json"
            plan_file = stage / "pause-plan.json"
            proof_report = stage / "recovery-proof-report.json"
            proof_baseline = stage / "recovery-proof-baseline.json"
            checks["bound_files_private"] = checks["stage_private"] and all(
                private_file(path) and 0 < path.stat().st_size <= limit
                for path, limit in ((candidate, MAX_MANIFEST), (plan_file, 4096),
                                    (proof_report, 4096), (proof_baseline, 4096))
            )
            if checks["bound_files_private"]:
                raw = candidate.read_bytes()
                proof = json.loads(proof_report.read_bytes(), object_pairs_hook=no_duplicate_keys)
                checks["candidate_bound"] = hashlib.sha256(raw).hexdigest() == expected and valid_manifest(raw)
                checks["plan_bound"] = hashlib.sha256(plan_file.read_bytes()).hexdigest() == plan_sha256
                checks["proof_accepted"] = (
                    isinstance(proof, dict) and proof.get("phase") == "release-recovery-proof"
                    and proof.get("status") == "PASS"
                    and isinstance(proof.get("checks"), dict) and bool(proof["checks"])
                    and all(value is True for value in proof["checks"].values())
                )
            if all(checks.values()):
                source_sha = json.loads(raw, object_pairs_hook=no_duplicate_keys)["configuration"]["source_sha"]
                checks["reviewed_checkout"] = reviewed_checkout(source_sha)
                checks["reviewed_script"] = reviewed_script(MIGRATION_READY_SCRIPT)
                checks["profile_bound"] = profile_bound()
            if (checks.get("reviewed_checkout") and checks.get("reviewed_script")
                    and checks.get("profile_bound")):
                EXTERNAL_REPORTS.mkdir(mode=0o700, exist_ok=True)
                checks["external_report_directory_private"] = private_directory(EXTERNAL_REPORTS)
            if (checks.get("external_report_directory_private")
                    and checks.get("dispatch_report_available")):
                write_private(stage / "ready-dispatch-start.json", b'{"phase":"ready-dispatch","status":"INCOMPLETE"}\n')
                checks["dispatch_reserved"] = True
                external = EXTERNAL_REPORTS / f"{run_id}-migration-ready.json"
                result = subprocess.run(
                    ["/usr/bin/python3", "-I", "-B", str(MIGRATION_READY_SCRIPT),
                     "--profile", str(BACKUP_PROFILE), "--stage-run-id", run_id,
                     "--manifest-sha256", expected, "--plan-sha256", plan_sha256,
                     "--report", str(external)],
                    env={"PATH": "/usr/bin:/bin", "PYTHONNOUSERSITE": "1",
                         "PYTHONDONTWRITEBYTECODE": "1", "PYTHONSAFEPATH": "1"},
                    capture_output=True, timeout=300, check=False,
                )
                evidence = json.loads(external.read_bytes(), object_pairs_hook=no_duplicate_keys)
                checks["ready_passed"] = (
                    result.returncode == 0 and result.stdout.strip() == b"PASS"
                    and isinstance(evidence, dict) and evidence.get("phase") == "release-migration-ready"
                    and evidence.get("status") == "PASS"
                    and isinstance(evidence.get("checks"), dict) and bool(evidence["checks"])
                    and all(value is True for value in evidence["checks"].values())
                )
            if checks.get("ready_passed"):
                readiness = stage / "migration-ready-baseline.json"
                checks["readiness_private_bounded"] = (
                    private_file(readiness) and 0 < readiness.stat().st_size <= 4096
                )
                if checks["readiness_private_bounded"]:
                    readiness_sha256 = hashlib.sha256(readiness.read_bytes()).hexdigest()
        except (OSError, ValueError, TypeError, KeyError, subprocess.TimeoutExpired):
            checks["ready_execution"] = False
    status = "PASS" if all(checks.values()) and readiness_sha256 is not None else "STOP"
    report = {"phase": "release-migration-readiness-dispatch", "status": status, "checks": checks}
    if status == "PASS":
        report["readiness_sha256"] = readiness_sha256
    if checks.get("dispatch_reserved"):
        try:
            write_private(stage / "ready-dispatch-report.json", (json.dumps(report, sort_keys=True) + "\n").encode())
        except OSError:
            report = {"phase": "release-migration-readiness-dispatch", "status": "STOP", "checks": {"report_write": False}}
    print(json.dumps(report, sort_keys=True))
    return 0 if report["status"] == "PASS" else 1


def promotion_ready_release(expected, run_id, plan_sha256, readiness_sha256):
    """Verify migrations and record the final promotion baseline."""
    stage = EVIDENCE / "release-stages" / run_id
    checks = {
        "root_execution": os.geteuid() == 0,
        "request_shape": bool(SHA256.fullmatch(expected)) and bool(RUN.fullmatch(run_id))
            and bool(SHA256.fullmatch(plan_sha256)) and bool(SHA256.fullmatch(readiness_sha256)),
        "read_only_baseline": access_check(),
    }
    promotion_sha256 = None
    if all(checks.values()):
        try:
            checks["stage_private"] = private_directory(stage)
            checks["dispatch_report_available"] = (
                not (stage / "promotion-ready-dispatch-report.json").exists()
                and not (stage / "promotion-ready-dispatch-report.json").is_symlink()
            ) if checks["stage_private"] else False
            candidate = stage / "candidate.json"
            plan_file = stage / "pause-plan.json"
            ready_report = stage / "migration-ready-report.json"
            ready_baseline = stage / "migration-ready-baseline.json"
            checks["bound_files_private"] = checks["stage_private"] and all(
                private_file(path) and 0 < path.stat().st_size <= limit
                for path, limit in ((candidate, MAX_MANIFEST), (plan_file, 4096),
                                    (ready_report, 4096), (ready_baseline, 4096))
            )
            if checks["bound_files_private"]:
                raw = candidate.read_bytes()
                ready = json.loads(ready_report.read_bytes(), object_pairs_hook=no_duplicate_keys)
                checks["candidate_bound"] = hashlib.sha256(raw).hexdigest() == expected and valid_manifest(raw)
                checks["plan_bound"] = hashlib.sha256(plan_file.read_bytes()).hexdigest() == plan_sha256
                checks["readiness_bound"] = hashlib.sha256(ready_baseline.read_bytes()).hexdigest() == readiness_sha256
                checks["readiness_accepted"] = (
                    isinstance(ready, dict) and ready.get("phase") == "release-migration-ready"
                    and ready.get("status") == "PASS"
                    and isinstance(ready.get("checks"), dict) and bool(ready["checks"])
                    and all(value is True for value in ready["checks"].values())
                )
            if all(checks.values()):
                source_sha = json.loads(raw, object_pairs_hook=no_duplicate_keys)["configuration"]["source_sha"]
                checks["reviewed_checkout"] = reviewed_checkout(source_sha)
                checks["reviewed_script"] = reviewed_script(PROMOTION_READY_SCRIPT)
                checks["profile_bound"] = profile_bound()
            if (checks.get("reviewed_checkout") and checks.get("reviewed_script")
                    and checks.get("profile_bound")):
                EXTERNAL_REPORTS.mkdir(mode=0o700, exist_ok=True)
                checks["external_report_directory_private"] = private_directory(EXTERNAL_REPORTS)
            if (checks.get("external_report_directory_private")
                    and checks.get("dispatch_report_available")):
                write_private(stage / "promotion-ready-dispatch-start.json", b'{"phase":"promotion-ready-dispatch","status":"INCOMPLETE"}\n')
                checks["dispatch_reserved"] = True
                external = EXTERNAL_REPORTS / f"{run_id}-promotion-ready.json"
                result = subprocess.run(
                    ["/usr/bin/python3", "-I", "-B", str(PROMOTION_READY_SCRIPT),
                     "--profile", str(BACKUP_PROFILE), "--stage-run-id", run_id,
                     "--manifest-sha256", expected, "--plan-sha256", plan_sha256,
                     "--readiness-sha256", readiness_sha256,
                     "--report", str(external)],
                    env={"PATH": "/usr/bin:/bin", "PYTHONNOUSERSITE": "1",
                         "PYTHONDONTWRITEBYTECODE": "1", "PYTHONSAFEPATH": "1"},
                    capture_output=True, timeout=300, check=False,
                )
                evidence = json.loads(external.read_bytes(), object_pairs_hook=no_duplicate_keys)
                checks["promotion_ready_passed"] = (
                    result.returncode == 0 and result.stdout.strip() == b"PASS"
                    and isinstance(evidence, dict) and evidence.get("phase") == "release-promotion-ready"
                    and evidence.get("status") == "PASS"
                    and isinstance(evidence.get("checks"), dict) and bool(evidence["checks"])
                    and all(value is True for value in evidence["checks"].values())
                )
            if checks.get("promotion_ready_passed"):
                promotion = stage / "promotion-ready-baseline.json"
                checks["promotion_private_bounded"] = (
                    private_file(promotion) and 0 < promotion.stat().st_size <= 4096
                )
                if checks["promotion_private_bounded"]:
                    promotion_sha256 = hashlib.sha256(promotion.read_bytes()).hexdigest()
        except (OSError, ValueError, TypeError, KeyError, subprocess.TimeoutExpired):
            checks["promotion_ready_execution"] = False
    status = "PASS" if all(checks.values()) and promotion_sha256 is not None else "STOP"
    report = {"phase": "release-promotion-readiness-dispatch", "status": status, "checks": checks}
    if status == "PASS":
        report["promotion_sha256"] = promotion_sha256
    if checks.get("dispatch_reserved"):
        try:
            write_private(stage / "promotion-ready-dispatch-report.json", (json.dumps(report, sort_keys=True) + "\n").encode())
        except OSError:
            report = {"phase": "release-promotion-readiness-dispatch", "status": "STOP", "checks": {"report_write": False}}
    print(json.dumps(report, sort_keys=True))
    return 0 if report["status"] == "PASS" else 1


def migrate_release(expected, run_id, plan_sha256, readiness_sha256, database):
    """Run one confirmed candidate migration after exact readiness proof."""
    stage = EVIDENCE / "release-stages" / run_id
    checks = {
        "root_execution": os.geteuid() == 0,
        "request_shape": bool(SHA256.fullmatch(expected)) and bool(RUN.fullmatch(run_id))
            and bool(SHA256.fullmatch(plan_sha256))
            and bool(SHA256.fullmatch(readiness_sha256)) and database in ("siege", "mom"),
        "read_only_baseline": access_check(),
    }
    if all(checks.values()):
        try:
            checks["stage_private"] = private_directory(stage)
            checks["dispatch_report_available"] = (
                not (stage / f"migrate-{database}-dispatch-report.json").exists()
                and not (stage / f"migrate-{database}-dispatch-report.json").is_symlink()
            ) if checks["stage_private"] else False
            candidate = stage / "candidate.json"
            plan_file = stage / "pause-plan.json"
            ready_report = stage / "migration-ready-report.json"
            ready_baseline = stage / "migration-ready-baseline.json"
            checks["bound_files_private"] = checks["stage_private"] and all(
                private_file(path) and 0 < path.stat().st_size <= limit
                for path, limit in ((candidate, MAX_MANIFEST), (plan_file, 4096),
                                    (ready_report, 4096), (ready_baseline, 4096))
            )
            if checks["bound_files_private"]:
                raw = candidate.read_bytes()
                ready = json.loads(ready_report.read_bytes(), object_pairs_hook=no_duplicate_keys)
                checks["candidate_bound"] = hashlib.sha256(raw).hexdigest() == expected and valid_manifest(raw)
                checks["plan_bound"] = hashlib.sha256(plan_file.read_bytes()).hexdigest() == plan_sha256
                checks["readiness_bound"] = hashlib.sha256(ready_baseline.read_bytes()).hexdigest() == readiness_sha256
                checks["readiness_accepted"] = (
                    isinstance(ready, dict) and ready.get("phase") == "release-migration-ready"
                    and ready.get("status") == "PASS"
                    and isinstance(ready.get("checks"), dict) and bool(ready["checks"])
                    and all(value is True for value in ready["checks"].values())
                )
            if all(checks.values()):
                source_sha = json.loads(raw, object_pairs_hook=no_duplicate_keys)["configuration"]["source_sha"]
                checks["reviewed_checkout"] = reviewed_checkout(source_sha)
                checks["reviewed_script"] = reviewed_script(MIGRATE_SCRIPT)
                checks["profile_bound"] = profile_bound()
            if (checks.get("reviewed_checkout") and checks.get("reviewed_script")
                    and checks.get("profile_bound")):
                EXTERNAL_REPORTS.mkdir(mode=0o700, exist_ok=True)
                checks["external_report_directory_private"] = private_directory(EXTERNAL_REPORTS)
            if (checks.get("external_report_directory_private")
                    and checks.get("dispatch_report_available")):
                write_private(stage / f"migrate-{database}-dispatch-start.json", b'{"phase":"migrate-dispatch","status":"INCOMPLETE"}\n')
                checks["dispatch_reserved"] = True
                external = EXTERNAL_REPORTS / f"{run_id}-migrate-{database}.json"
                result = subprocess.run(
                    ["/usr/bin/python3", "-I", "-B", str(MIGRATE_SCRIPT),
                     "--profile", str(BACKUP_PROFILE), "--stage-run-id", run_id,
                     "--manifest-sha256", expected, "--plan-sha256", plan_sha256,
                     "--readiness-sha256", readiness_sha256, "--database", database,
                     "--confirm-migrate", database, "--report", str(external)],
                    env={"PATH": "/usr/bin:/bin", "PYTHONNOUSERSITE": "1",
                         "PYTHONDONTWRITEBYTECODE": "1", "PYTHONSAFEPATH": "1"},
                    capture_output=True, timeout=1100, check=False,
                )
                evidence = json.loads(external.read_bytes(), object_pairs_hook=no_duplicate_keys)
                checks["migration_passed"] = (
                    result.returncode == 0 and result.stdout.strip() == b"PASS"
                    and isinstance(evidence, dict) and evidence.get("phase") == f"migrate-{database}"
                    and evidence.get("status") == "PASS"
                    and isinstance(evidence.get("checks"), dict) and bool(evidence["checks"])
                    and all(value is True for value in evidence["checks"].values())
                )
        except (OSError, ValueError, TypeError, KeyError, subprocess.TimeoutExpired):
            checks["migration_execution"] = False
    status = "PASS" if all(checks.values()) else "STOP"
    report = {"phase": f"release-migrate-{database}-dispatch", "status": status, "checks": checks}
    if checks.get("dispatch_reserved"):
        try:
            write_private(stage / f"migrate-{database}-dispatch-report.json", (json.dumps(report, sort_keys=True) + "\n").encode())
        except OSError:
            report = {"phase": f"release-migrate-{database}-dispatch", "status": "STOP", "checks": {"report_write": False}}
    print(json.dumps(report, sort_keys=True))
    return 0 if report["status"] == "PASS" else 1


def promote_release(expected, run_id, plan_sha256, readiness_sha256, promotion_sha256):
    """Activate only the reviewed candidate after final promotion readiness."""
    stage = EVIDENCE / "release-stages" / run_id
    checks = {
        "root_execution": os.geteuid() == 0,
        "request_shape": bool(SHA256.fullmatch(expected)) and bool(RUN.fullmatch(run_id))
            and bool(SHA256.fullmatch(plan_sha256))
            and bool(SHA256.fullmatch(readiness_sha256))
            and bool(SHA256.fullmatch(promotion_sha256)),
        "read_only_baseline": access_check(),
    }
    if all(checks.values()):
        try:
            checks["stage_private"] = private_directory(stage)
            checks["dispatch_report_available"] = (
                not (stage / "promote-dispatch-report.json").exists()
                and not (stage / "promote-dispatch-report.json").is_symlink()
            ) if checks["stage_private"] else False
            candidate = stage / "candidate.json"
            plan_file = stage / "pause-plan.json"
            promotion_report = stage / "promotion-ready-report.json"
            promotion_baseline = stage / "promotion-ready-baseline.json"
            checks["bound_files_private"] = checks["stage_private"] and all(
                private_file(path) and 0 < path.stat().st_size <= limit
                for path, limit in ((candidate, MAX_MANIFEST), (plan_file, 4096),
                                    (promotion_report, 4096), (promotion_baseline, 4096))
            )
            if checks["bound_files_private"]:
                raw = candidate.read_bytes()
                promotion = json.loads(promotion_report.read_bytes(), object_pairs_hook=no_duplicate_keys)
                checks["candidate_bound"] = hashlib.sha256(raw).hexdigest() == expected and valid_manifest(raw)
                checks["plan_bound"] = hashlib.sha256(plan_file.read_bytes()).hexdigest() == plan_sha256
                checks["promotion_bound"] = hashlib.sha256(promotion_baseline.read_bytes()).hexdigest() == promotion_sha256
                checks["promotion_accepted"] = (
                    isinstance(promotion, dict) and promotion.get("phase") == "release-promotion-ready"
                    and promotion.get("status") == "PASS"
                    and isinstance(promotion.get("checks"), dict) and bool(promotion["checks"])
                    and all(value is True for value in promotion["checks"].values())
                )
            if all(checks.values()):
                source_sha = json.loads(raw, object_pairs_hook=no_duplicate_keys)["configuration"]["source_sha"]
                checks["reviewed_checkout"] = reviewed_checkout(source_sha)
                checks["reviewed_script"] = reviewed_script(PROMOTE_SCRIPT)
                checks["profile_bound"] = profile_bound()
            if (checks.get("reviewed_checkout") and checks.get("reviewed_script")
                    and checks.get("profile_bound")):
                EXTERNAL_REPORTS.mkdir(mode=0o700, exist_ok=True)
                checks["external_report_directory_private"] = private_directory(EXTERNAL_REPORTS)
            if (checks.get("external_report_directory_private")
                    and checks.get("dispatch_report_available")):
                write_private(stage / "promote-dispatch-start.json", b'{"phase":"promote-dispatch","status":"INCOMPLETE"}\n')
                checks["dispatch_reserved"] = True
                external = EXTERNAL_REPORTS / f"{run_id}-promote.json"
                result = subprocess.run(
                    ["/usr/bin/python3", "-I", "-B", str(PROMOTE_SCRIPT),
                     "--profile", str(BACKUP_PROFILE), "--stage-run-id", run_id,
                     "--manifest-sha256", expected, "--plan-sha256", plan_sha256,
                     "--readiness-sha256", readiness_sha256,
                     "--promotion-ready-sha256", promotion_sha256,
                     "--confirm-promote", run_id, "--report", str(external)],
                    env={"PATH": "/usr/bin:/bin", "PYTHONNOUSERSITE": "1",
                         "PYTHONDONTWRITEBYTECODE": "1", "PYTHONSAFEPATH": "1"},
                    capture_output=True, timeout=700, check=False,
                )
                evidence = json.loads(external.read_bytes(), object_pairs_hook=no_duplicate_keys)
                checks["promotion_passed"] = (
                    result.returncode == 0 and result.stdout.strip() == b"PASS"
                    and isinstance(evidence, dict) and evidence.get("phase") == "release-promote"
                    and evidence.get("status") == "PASS"
                    and isinstance(evidence.get("checks"), dict) and bool(evidence["checks"])
                    and all(value is True for value in evidence["checks"].values())
                )
        except (OSError, ValueError, TypeError, KeyError, subprocess.TimeoutExpired):
            checks["promotion_execution"] = False
    status = "PASS" if all(checks.values()) else "STOP"
    report = {"phase": "release-promotion-dispatch", "status": status, "checks": checks}
    if checks.get("dispatch_reserved"):
        try:
            write_private(stage / "promote-dispatch-report.json", (json.dumps(report, sort_keys=True) + "\n").encode())
        except OSError:
            report = {"phase": "release-promotion-dispatch", "status": "STOP", "checks": {"report_write": False}}
    print(json.dumps(report, sort_keys=True))
    return 0 if report["status"] == "PASS" else 1


def accept_release(expected, run_id, plan_sha256, readiness_sha256, promotion_sha256):
    """Run read-only acceptance with fixed, operator-owned private inputs."""
    stage = EVIDENCE / "release-stages" / run_id
    checks = {
        "root_execution": os.geteuid() == 0,
        "request_shape": bool(SHA256.fullmatch(expected)) and bool(RUN.fullmatch(run_id))
            and all(SHA256.fullmatch(value) for value in
                    (plan_sha256, readiness_sha256, promotion_sha256)),
        "read_only_baseline": access_check(),
    }
    if all(checks.values()):
        try:
            checks["stage_private"] = private_directory(stage)
            checks["dispatch_report_available"] = (
                not (stage / "accept-dispatch-report.json").exists()
                and not (stage / "accept-dispatch-report.json").is_symlink()
            ) if checks["stage_private"] else False
            candidate = stage / "candidate.json"
            plan_file = stage / "pause-plan.json"
            promotion_baseline = stage / "promotion-ready-baseline.json"
            promotion_report = stage / "promotion-ready-report.json"
            promoted = stage / "promote-report.json"
            dispatched = stage / "promote-dispatch-report.json"
            checks["bound_files_private"] = checks["stage_private"] and all(
                private_file(path) and 0 < path.stat().st_size <= limit
                for path, limit in ((candidate, MAX_MANIFEST), (plan_file, 4096),
                                    (promotion_baseline, 4096), (promotion_report, 4096),
                                    (promoted, 4096), (dispatched, 4096))
            )
            if checks["bound_files_private"]:
                raw = candidate.read_bytes()
                promotion = json.loads(promotion_report.read_bytes(), object_pairs_hook=no_duplicate_keys)
                reports = [json.loads(path.read_bytes(), object_pairs_hook=no_duplicate_keys)
                           for path in (promoted, dispatched)]
                checks["candidate_bound"] = hashlib.sha256(raw).hexdigest() == expected and valid_manifest(raw)
                checks["plan_bound"] = hashlib.sha256(plan_file.read_bytes()).hexdigest() == plan_sha256
                checks["promotion_bound"] = hashlib.sha256(promotion_baseline.read_bytes()).hexdigest() == promotion_sha256
                checks["promotion_accepted"] = (
                    isinstance(promotion, dict) and promotion.get("phase") == "release-promotion-ready"
                    and promotion.get("status") == "PASS" and isinstance(promotion.get("checks"), dict)
                    and bool(promotion["checks"]) and all(value is True for value in promotion["checks"].values())
                )
                checks["promotion_completed"] = all(
                    isinstance(report, dict) and report.get("phase") == phase
                    and report.get("status") == "PASS" and isinstance(report.get("checks"), dict)
                    and bool(report["checks"]) and all(value is True for value in report["checks"].values())
                    for report, phase in zip(reports, ("release-promote", "release-promotion-dispatch"))
                )
            if all(checks.values()):
                source_sha = json.loads(raw, object_pairs_hook=no_duplicate_keys)["configuration"]["source_sha"]
                checks["reviewed_checkout"] = reviewed_checkout(source_sha)
                checks["reviewed_script"] = reviewed_script(ACCEPT_SCRIPT)
                checks["profile_bound"] = profile_bound()
                checks["operator_inputs_private"] = (
                    private_directory(ACCEPT_INPUTS)
                    and private_file(PILOT_CONFIG) and 0 < PILOT_CONFIG.stat().st_size <= 16384
                    and private_file(SESSION_COOKIE) and 0 < SESSION_COOKIE.stat().st_size <= 4096
                )
            if (checks.get("reviewed_checkout") and checks.get("reviewed_script")
                    and checks.get("profile_bound") and checks.get("operator_inputs_private")):
                EXTERNAL_REPORTS.mkdir(mode=0o700, exist_ok=True)
                checks["external_report_directory_private"] = private_directory(EXTERNAL_REPORTS)
            if (checks.get("external_report_directory_private")
                    and checks.get("dispatch_report_available")):
                write_private(stage / "accept-dispatch-start.json", b'{"phase":"accept-dispatch","status":"INCOMPLETE"}\n')
                checks["dispatch_reserved"] = True
                external = EXTERNAL_REPORTS / f"{run_id}-accept.json"
                result = subprocess.run(
                    ["/usr/bin/python3", "-I", "-B", str(ACCEPT_SCRIPT),
                     "--profile", str(BACKUP_PROFILE), "--stage-run-id", run_id,
                     "--manifest-sha256", expected, "--plan-sha256", plan_sha256,
                     "--readiness-sha256", readiness_sha256,
                     "--promotion-ready-sha256", promotion_sha256,
                     "--pilot-config", str(PILOT_CONFIG),
                     "--session-cookie-file", str(SESSION_COOKIE),
                     "--confirm-readonly-acceptance", "--report", str(external)],
                    env={"PATH": "/usr/bin:/bin", "PYTHONNOUSERSITE": "1",
                         "PYTHONDONTWRITEBYTECODE": "1", "PYTHONSAFEPATH": "1"},
                    capture_output=True, timeout=900, check=False,
                )
                evidence = json.loads(external.read_bytes(), object_pairs_hook=no_duplicate_keys)
                checks["acceptance_passed"] = (
                    result.returncode == 0 and result.stdout.strip() == b"PASS"
                    and isinstance(evidence, dict) and evidence.get("phase") == "release-accept"
                    and evidence.get("status") == "PASS" and isinstance(evidence.get("checks"), dict)
                    and bool(evidence["checks"]) and all(value is True for value in evidence["checks"].values())
                )
        except (OSError, ValueError, TypeError, KeyError, subprocess.TimeoutExpired):
            checks["acceptance_execution"] = False
    status = "PASS" if all(checks.values()) else "STOP"
    report = {"phase": "release-acceptance-dispatch", "status": status, "checks": checks}
    if checks.get("dispatch_reserved"):
        try:
            write_private(stage / "accept-dispatch-report.json", (json.dumps(report, sort_keys=True) + "\n").encode())
        except OSError:
            report = {"phase": "release-acceptance-dispatch", "status": "STOP", "checks": {"report_write": False}}
    print(json.dumps(report, sort_keys=True))
    return 0 if report["status"] == "PASS" else 1


def inspect_recovery(expected, run_id, plan_sha256, readiness_sha256, promotion_sha256):
    """Classify only the candidate's pre-activation recovery boundary."""
    stage = EVIDENCE / "release-stages" / run_id
    checks = {
        "root_execution": os.geteuid() == 0,
        "request_shape": bool(SHA256.fullmatch(expected)) and bool(RUN.fullmatch(run_id))
            and all(SHA256.fullmatch(value) for value in
                    (plan_sha256, readiness_sha256, promotion_sha256)),
        "read_only_baseline": access_check(),
    }
    if all(checks.values()):
        try:
            checks["stage_private"] = private_directory(stage)
            checks["dispatch_report_available"] = (
                not (stage / "recover-inspect-dispatch-report.json").exists()
                and not (stage / "recover-inspect-dispatch-report.json").is_symlink()
            ) if checks["stage_private"] else False
            candidate = stage / "candidate.json"
            plan_file = stage / "pause-plan.json"
            promotion_baseline = stage / "promotion-ready-baseline.json"
            promotion_report = stage / "promotion-ready-report.json"
            promote_start = stage / "promote-start.json"
            checks["bound_files_private"] = checks["stage_private"] and all(
                private_file(path) and 0 < path.stat().st_size <= limit
                for path, limit in ((candidate, MAX_MANIFEST), (plan_file, 4096),
                                    (promotion_baseline, 4096), (promotion_report, 4096),
                                    (promote_start, 4096))
            )
            if checks["bound_files_private"]:
                raw = candidate.read_bytes()
                promotion = json.loads(promotion_report.read_bytes(), object_pairs_hook=no_duplicate_keys)
                started = json.loads(promote_start.read_bytes(), object_pairs_hook=no_duplicate_keys)
                checks["candidate_bound"] = hashlib.sha256(raw).hexdigest() == expected and valid_manifest(raw)
                checks["plan_bound"] = hashlib.sha256(plan_file.read_bytes()).hexdigest() == plan_sha256
                checks["promotion_bound"] = hashlib.sha256(promotion_baseline.read_bytes()).hexdigest() == promotion_sha256
                checks["promotion_accepted"] = (
                    isinstance(promotion, dict) and promotion.get("phase") == "release-promotion-ready"
                    and promotion.get("status") == "PASS" and isinstance(promotion.get("checks"), dict)
                    and bool(promotion["checks"]) and all(value is True for value in promotion["checks"].values())
                )
                checks["promotion_attempt_bound"] = (
                    isinstance(started, dict) and started.get("phase") == "promote-start"
                    and started.get("manifest_sha256") == expected
                    and started.get("plan_sha256") == plan_sha256
                    and started.get("promotion_ready_sha256") == promotion_sha256
                )
            if all(checks.values()):
                source_sha = json.loads(raw, object_pairs_hook=no_duplicate_keys)["configuration"]["source_sha"]
                checks["reviewed_checkout"] = reviewed_checkout(source_sha)
                checks["reviewed_script"] = reviewed_script(RECOVER_SCRIPT)
                checks["profile_bound"] = profile_bound()
            if (checks.get("reviewed_checkout") and checks.get("reviewed_script")
                    and checks.get("profile_bound")):
                EXTERNAL_REPORTS.mkdir(mode=0o700, exist_ok=True)
                checks["external_report_directory_private"] = private_directory(EXTERNAL_REPORTS)
            if (checks.get("external_report_directory_private")
                    and checks.get("dispatch_report_available")):
                write_private(stage / "recover-inspect-dispatch-start.json", b'{"phase":"recover-inspect-dispatch","status":"INCOMPLETE"}\n')
                checks["dispatch_reserved"] = True
                external = EXTERNAL_REPORTS / f"{run_id}-recover-inspect.json"
                result = subprocess.run(
                    ["/usr/bin/python3", "-I", "-B", str(RECOVER_SCRIPT), "inspect",
                     "--profile", str(BACKUP_PROFILE), "--stage-run-id", run_id,
                     "--manifest-sha256", expected, "--plan-sha256", plan_sha256,
                     "--readiness-sha256", readiness_sha256,
                     "--promotion-ready-sha256", promotion_sha256,
                     "--report", str(external)],
                    env={"PATH": "/usr/bin:/bin", "PYTHONNOUSERSITE": "1",
                         "PYTHONDONTWRITEBYTECODE": "1", "PYTHONSAFEPATH": "1"},
                    capture_output=True, timeout=300, check=False,
                )
                evidence = json.loads(external.read_bytes(), object_pairs_hook=no_duplicate_keys)
                checks["recovery_inspection_passed"] = (
                    result.returncode == 0 and result.stdout.strip() == b"PASS"
                    and isinstance(evidence, dict) and evidence.get("phase") == "release-recover-inspect"
                    and evidence.get("status") == "PASS"
                    and evidence.get("manual_reconciliation_required") is False
                    and isinstance(evidence.get("checks"), dict) and bool(evidence["checks"])
                    and all(value is True for value in evidence["checks"].values())
                )
        except (OSError, ValueError, TypeError, KeyError, subprocess.TimeoutExpired):
            checks["recovery_inspection_execution"] = False
    status = "PASS" if all(checks.values()) else "STOP"
    report = {"phase": "release-recovery-inspection-dispatch", "status": status, "checks": checks}
    if checks.get("dispatch_reserved"):
        try:
            write_private(stage / "recover-inspect-dispatch-report.json", (json.dumps(report, sort_keys=True) + "\n").encode())
        except OSError:
            report = {"phase": "release-recovery-inspection-dispatch", "status": "STOP", "checks": {"report_write": False}}
    print(json.dumps(report, sort_keys=True))
    return 0 if report["status"] == "PASS" else 1


def restore_recovery(expected, run_id, plan_sha256, readiness_sha256, promotion_sha256):
    """Restore only the original protected configuration after a passed inspection."""
    stage = EVIDENCE / "release-stages" / run_id
    checks = {
        "root_execution": os.geteuid() == 0,
        "request_shape": bool(SHA256.fullmatch(expected)) and bool(RUN.fullmatch(run_id))
            and all(SHA256.fullmatch(value) for value in
                    (plan_sha256, readiness_sha256, promotion_sha256)),
        "read_only_baseline": access_check(),
    }
    if all(checks.values()):
        try:
            checks["stage_private"] = private_directory(stage)
            checks["dispatch_report_available"] = (
                not (stage / "recover-preactivation-dispatch-start.json").exists()
                and not (stage / "recover-preactivation-dispatch-start.json").is_symlink()
                and not (stage / "recover-preactivation-dispatch-report.json").exists()
                and not (stage / "recover-preactivation-dispatch-report.json").is_symlink()
            ) if checks["stage_private"] else False
            candidate = stage / "candidate.json"
            plan_file = stage / "pause-plan.json"
            promotion_baseline = stage / "promotion-ready-baseline.json"
            inspection = stage / "recover-inspect-report.json"
            inspection_dispatch = stage / "recover-inspect-dispatch-report.json"
            checks["bound_files_private"] = checks["stage_private"] and all(
                private_file(path) and 0 < path.stat().st_size <= limit
                for path, limit in ((candidate, MAX_MANIFEST), (plan_file, 4096),
                                    (promotion_baseline, 4096), (inspection, 4096),
                                    (inspection_dispatch, 4096))
            )
            if checks["bound_files_private"]:
                raw = candidate.read_bytes()
                reports = [json.loads(path.read_bytes(), object_pairs_hook=no_duplicate_keys)
                           for path in (inspection, inspection_dispatch)]
                checks["candidate_bound"] = hashlib.sha256(raw).hexdigest() == expected and valid_manifest(raw)
                checks["plan_bound"] = hashlib.sha256(plan_file.read_bytes()).hexdigest() == plan_sha256
                checks["promotion_bound"] = hashlib.sha256(promotion_baseline.read_bytes()).hexdigest() == promotion_sha256
                checks["inspection_accepted"] = (
                    isinstance(reports[0], dict) and reports[0].get("phase") == "release-recover-inspect"
                    and reports[0].get("status") == "PASS"
                    and reports[0].get("manual_reconciliation_required") is False
                    and isinstance(reports[0].get("checks"), dict) and bool(reports[0]["checks"])
                    and all(value is True for value in reports[0]["checks"].values())
                    and isinstance(reports[1], dict)
                    and reports[1].get("phase") == "release-recovery-inspection-dispatch"
                    and reports[1].get("status") == "PASS"
                    and isinstance(reports[1].get("checks"), dict) and bool(reports[1]["checks"])
                    and all(value is True for value in reports[1]["checks"].values())
                )
            if all(checks.values()):
                source_sha = json.loads(raw, object_pairs_hook=no_duplicate_keys)["configuration"]["source_sha"]
                checks["reviewed_checkout"] = reviewed_checkout(source_sha)
                checks["reviewed_script"] = reviewed_script(RECOVER_SCRIPT)
                checks["profile_bound"] = profile_bound()
            if (checks.get("reviewed_checkout") and checks.get("reviewed_script")
                    and checks.get("profile_bound")):
                EXTERNAL_REPORTS.mkdir(mode=0o700, exist_ok=True)
                checks["external_report_directory_private"] = private_directory(EXTERNAL_REPORTS)
            if (checks.get("external_report_directory_private")
                    and checks.get("dispatch_report_available")):
                write_private(stage / "recover-preactivation-dispatch-start.json",
                              b'{"phase":"recover-preactivation-dispatch","status":"INCOMPLETE"}\n')
                checks["dispatch_reserved"] = True
                external = EXTERNAL_REPORTS / f"{run_id}-recover-preactivation.json"
                result = subprocess.run(
                    ["/usr/bin/python3", "-I", "-B", str(RECOVER_SCRIPT), "restore-preactivation",
                     "--profile", str(BACKUP_PROFILE), "--stage-run-id", run_id,
                     "--manifest-sha256", expected, "--plan-sha256", plan_sha256,
                     "--readiness-sha256", readiness_sha256,
                     "--promotion-ready-sha256", promotion_sha256,
                     "--confirm-restore", run_id, "--report", str(external)],
                    env={"PATH": "/usr/bin:/bin", "PYTHONNOUSERSITE": "1",
                         "PYTHONDONTWRITEBYTECODE": "1", "PYTHONSAFEPATH": "1"},
                    capture_output=True, timeout=900, check=False,
                )
                evidence = json.loads(external.read_bytes(), object_pairs_hook=no_duplicate_keys)
                checks["configuration_restored"] = (
                    result.returncode == 0 and result.stdout.strip() == b"PASS"
                    and isinstance(evidence, dict)
                    and evidence.get("phase") == "release-recover-restore-preactivation"
                    and evidence.get("status") == "PASS"
                    and evidence.get("manual_reconciliation_required") is False
                    and isinstance(evidence.get("checks"), dict) and bool(evidence["checks"])
                    and all(value is True for value in evidence["checks"].values())
                )
        except (OSError, ValueError, TypeError, KeyError, subprocess.TimeoutExpired):
            checks["restore_execution"] = False
    status = "PASS" if all(checks.values()) else "STOP"
    report = {"phase": "release-recovery-restore-dispatch", "status": status,
              "manual_reconciliation_required": status != "PASS", "checks": checks}
    if checks.get("dispatch_reserved"):
        try:
            write_private(stage / "recover-preactivation-dispatch-report.json",
                          (json.dumps(report, sort_keys=True) + "\n").encode())
        except OSError:
            report = {"phase": "release-recovery-restore-dispatch", "status": "STOP",
                      "manual_reconciliation_required": True, "checks": {"report_write": False}}
    print(json.dumps(report, sort_keys=True))
    return 0 if report["status"] == "PASS" else 1


def main():
    # The SSH key must be restricted to this absolute command in authorized_keys.
    # Never dispatch arbitrary SSH_ORIGINAL_COMMAND text to a shell.
    command = os.environ.get("SSH_ORIGINAL_COMMAND", "")
    if command == "access-check":
        if access_check():
            print("PASS")
            return 0
        print("STOP")
        return 1
    parts = command.split(" ")
    if len(parts) == 4 and parts[0] == "stage-release" and parts[3] == "confirm-stage":
        return stage_release(parts[1], parts[2], sys.stdin.buffer)
    if len(parts) == 4 and parts[0] == "preflight-release" and parts[3] == "confirm-readonly-preflight":
        return preflight_release(parts[1], parts[2])
    if len(parts) == 4 and parts[0] == "plan-release" and parts[3] == "confirm-readonly-plan":
        return plan_release(parts[1], parts[2])
    if len(parts) == 5 and parts[0] == "pause-release" and parts[4] == "confirm-pause":
        return pause_release(parts[1], parts[2], parts[3])
    if len(parts) == 5 and parts[0] == "backup-release" and parts[4] == "confirm-backup":
        return backup_release(parts[1], parts[2], parts[3])
    if len(parts) == 7 and parts[0] == "proof-release" and parts[6] == "confirm-readonly-proof":
        return proof_release(parts[1], parts[2], parts[3], parts[4], parts[5])
    if len(parts) == 5 and parts[0] == "ready-release" and parts[4] == "confirm-readonly-ready":
        return ready_release(parts[1], parts[2], parts[3])
    if (len(parts) == 7 and parts[0] == "migrate-release" and parts[5] in ("siege", "mom")
            and parts[6] == f"confirm-migrate-{parts[5]}"):
        return migrate_release(parts[1], parts[2], parts[3], parts[4], parts[5])
    if (len(parts) == 6 and parts[0] == "promotion-ready-release"
            and parts[5] == "confirm-readonly-promotion-ready"):
        return promotion_ready_release(parts[1], parts[2], parts[3], parts[4])
    if (len(parts) == 7 and parts[0] == "promote-release"
            and parts[6] == f"confirm-promote-{parts[2]}"):
        return promote_release(parts[1], parts[2], parts[3], parts[4], parts[5])
    if (len(parts) == 7 and parts[0] == "accept-release"
            and parts[6] == "confirm-readonly-acceptance"):
        return accept_release(parts[1], parts[2], parts[3], parts[4], parts[5])
    if (len(parts) == 7 and parts[0] == "recover-inspect-release"
            and parts[6] == "confirm-readonly-recovery-inspect"):
        return inspect_recovery(parts[1], parts[2], parts[3], parts[4], parts[5])
    if (len(parts) == 7 and parts[0] == "recover-restore-release"
            and parts[6] == f"confirm-restore-{parts[2]}"):
        return restore_recovery(parts[1], parts[2], parts[3], parts[4], parts[5])
    print("STOP")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
